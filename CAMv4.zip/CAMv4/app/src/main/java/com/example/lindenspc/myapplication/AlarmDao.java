package com.example.lindenspc.myapplication;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

//Data access object

@Dao
public interface AlarmDao {
    @Query("SELECT * FROM alarm")
    List<Alarm> getAllUsers();

    @Insert
    void insertAll(Alarm... alarms);

    @Update
    void updateUser(Alarm alarm);


    @Query("DELETE FROM alarm")
    void delete();

    @Query("SELECT COUNT(*) FROM alarm")
    int getCount();

}
