package com.example.lindenspc.myapplication;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CreateAlarm extends AppCompatActivity {

    private static final String TAG = "CreateAlarm";

    boolean newEntry = true;
    EditText alarmName;
    EditText alarmTime;
    EditText alarmDate;
    Button button;

    private Alarm mUser;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_alarm);


        alarmName = findViewById(R.id.alarm_name);
        alarmTime = findViewById(R.id.alarm_time);
        alarmDate = findViewById(R.id.alarm_date);
        button = findViewById(R.id.button);

        TextView newEntryText = findViewById(R.id.new_entry);

        final AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries() //bad practice, should use background process
                .build();

        // db.userDao().delete();
        // User user2 = new User("Freddy", "Yang", "yangfreddy@yahoo.com");
        // db.userDao().insertAll(user2);

        // if user is editing existing alarm
        if (db.alarmDao().getCount() > 0) { // TODO create condition if user is updating alarm

            newEntryText.setText("UPDATE ENTRY");
            newEntry = false;
            Intent intent = getIntent();
            mUser = intent.getParcelableExtra("User Item");
            alarmName.setText(mUser.getFirstName());
            alarmTime.setText(mUser.getLastName());
            alarmDate.setText(mUser.getEmail());
        }
        // if user is creating new alarm
        else {
            alarmName.setText("Alarm Name");
            alarmTime.setText("Time");
            alarmDate.setText("Date");
        }








        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Log.d(TAG, "onClick: firstName: " + firstName.getText().toString());
                Alarm user = new Alarm(alarmName.getText().toString(), alarmTime.getText().toString(), alarmDate.getText().toString());

                if (newEntry == true)
                {
                    db.alarmDao().insertAll(user);
                }
                else {
                    db.alarmDao().updateUser(user); // TODO update field not working
                }



                startActivity(new Intent(CreateAlarm.this, MainActivity.class));
            }
        });

    }
}
