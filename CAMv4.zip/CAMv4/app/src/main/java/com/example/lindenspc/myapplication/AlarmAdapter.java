package com.example.lindenspc.myapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class AlarmAdapter extends RecyclerView.Adapter<AlarmAdapter.ViewHolder> {

    List<Alarm> users;
    private OnItemClickListener mListener;



    public interface OnItemClickListener {
        void onItemClick(int position); // position = index of item in recycler view
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }



    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView firstName;
        public TextView lastName;
        public TextView email;


        public ViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);

            firstName = itemView.findViewById(R.id.first_name);
            lastName = itemView.findViewById(R.id.last_name);
            email = itemView.findViewById(R.id.email);


            // allows each item in the recycler view to be clicked on
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (listener != null) {
                        int position = getAdapterPosition();

                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
        public AlarmAdapter(List<Alarm> users) {
            this.users = users;
        }

    @NonNull
    @Override
    public AlarmAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
           View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.alarm_row, viewGroup, false);
           ViewHolder viewHolder = new ViewHolder(view, mListener);

            return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull AlarmAdapter.ViewHolder viewHolder, int i) {

        viewHolder.firstName.setText(users.get(i).getFirstName());
        viewHolder.lastName.setText(users.get(i).getLastName());
        viewHolder.email.setText(users.get(i).getEmail());

    }

    @Override
    public int getItemCount() {
        return users.size();
    }


    }

