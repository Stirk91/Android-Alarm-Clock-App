package com.example.lindenspc.customalarmmanagerv2;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.ArrayList;

public class AlarmAdapter extends RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder> {

    private ArrayList<AlarmItem> mAlarmList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position); // position = index of item in recycler view
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }



    public static class AlarmViewHolder extends RecyclerView.ViewHolder {

        public ImageView mImageView;
        public TextView mTextView1;
        public TextView mTextView2;


        public AlarmViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);

            mImageView = itemView.findViewById(R.id.imageView);
            mTextView1 = itemView.findViewById(R.id.textView1);
            mTextView2 = itemView.findViewById(R.id.textView2);


            // allows each item in the recycler view to be clicked on
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (listener != null) {
                        int position = getAdapterPosition();

                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });


        }
    }


    public AlarmAdapter(ArrayList<AlarmItem> alarmList) {
        mAlarmList = alarmList;
    }

    @NonNull
    @Override
    public AlarmViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.alarm_item,viewGroup, false);
        AlarmViewHolder avh = new AlarmViewHolder(v, mListener);
        return avh;



    }

    @Override
    public void onBindViewHolder(@NonNull AlarmViewHolder avh, int index) {
        AlarmItem currentItem = mAlarmList.get(index);

        avh.mImageView.setImageResource(currentItem.getImageResource());
        avh.mTextView1.setText(currentItem.getText1());
        avh.mTextView2.setText(currentItem.getText2());

    }

    @Override
    public int getItemCount() {
        return mAlarmList.size();
    }
}
