package com.example.lindenspc.customalarmmanagerv2;

import android.os.Parcel;
import android.os.Parcelable;

public class AlarmItem implements Parcelable {
    private int mImageResource;
    private String mText1;
    private String mText2;


    public AlarmItem(){
        mImageResource = R.drawable.ic_timer;
        mText1 = "Alarm ";
        mText2 = "alarm details";
    }

    protected AlarmItem(Parcel in) {
        mImageResource = in.readInt();
        mText1 = in.readString();
        mText2 = in.readString();
    }

    public static final Creator<AlarmItem> CREATOR = new Creator<AlarmItem>() {
        @Override
        public AlarmItem createFromParcel(Parcel in) {
            return new AlarmItem(in);
        }

        @Override
        public AlarmItem[] newArray(int size) {
            return new AlarmItem[size];
        }
    };

    public int getImageResource() {
        return mImageResource;
    }

    public String getText1() {
        return mText1;
    }


    public String getText2() {
        return mText2;
    }

    public void setText1(String text1) {
        mText1 = text1;
    }

    public void setText2(String text2) {
        mText2 = text2;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mImageResource);
        dest.writeString(mText1);
        dest.writeString(mText2);
    }
}

