package com.example.lindenspc.customalarmmanagerv2;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<AlarmItem> mAlarmList;


    private RecyclerView mRecyclerView;
    private AlarmAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createAlarmList();
        buildRecyclerView();

        FloatingActionButton addAlarm = findViewById(R.id.addAlarmFAB);
        addAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertAlarm();
            }
        });
    }


        public void createAlarmList(){
        mAlarmList = new ArrayList<>();
        mAlarmList.add(new AlarmItem());
    }


    // adds new alarm in recycle view
    public void insertAlarm(){
        mAlarmList.add(new AlarmItem());
        mAdapter.notifyItemInserted(mAlarmList.size()-1);

    }

    public void buildRecyclerView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new AlarmAdapter(mAlarmList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(new AlarmAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                mAdapter.notifyItemChanged(position);
                Intent intent = new Intent(MainActivity.this, AlarmActivity.class);
                intent.putExtra("Alarm Item", mAlarmList.get(position));
                startActivity(intent);
            }
        });
    }

    // updates activity when restarting
    @Override
    protected void onResume() {
        super.onResume();
        mAdapter.notifyDataSetChanged();
    }






}


